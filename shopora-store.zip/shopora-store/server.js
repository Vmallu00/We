require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const methodOverride = require("method-override");

const app = express();
const PORT = process.env.PORT || 3000;
const STORE = process.env.STORE_NAME || "Shopora";
const CURRENCY = process.env.CURRENCY || "INR";
const db = new Database("data.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
 password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS categories (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, description TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT DEFAULT '',
 price REAL NOT NULL, compare_price REAL DEFAULT 0, stock INTEGER DEFAULT 0,
 category_id INTEGER, image TEXT DEFAULT '', active INTEGER DEFAULT 1,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(category_id) REFERENCES categories(id)
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, total REAL NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending', payment_method TEXT NOT NULL DEFAULT 'Cash on Delivery',
 payment_status TEXT NOT NULL DEFAULT 'Pending', customer_name TEXT NOT NULL,
 phone TEXT NOT NULL, address TEXT NOT NULL, notes TEXT DEFAULT '',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS order_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER,
 product_name TEXT NOT NULL, price REAL NOT NULL, quantity INTEGER NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id)
);
`);
const adminEmail = (process.env.ADMIN_EMAIL || "admin@example.com").toLowerCase();
const existingAdmin = db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail);
if (!existingAdmin) {
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD || "ChangeMe123!", 12);
  db.prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'admin')")
    .run(process.env.ADMIN_NAME || "Store Admin", adminEmail, hash);
}
if (!db.prepare("SELECT id FROM categories LIMIT 1").get()) {
  ["Electronics", "Fashion", "Home & Living", "Accessories"].forEach(n =>
    db.prepare("INSERT OR IGNORE INTO categories(name) VALUES(?)").run(n));
}

const uploadDir = path.join(__dirname, "public", "uploads");
fs.mkdirSync(uploadDir, {recursive:true});
const storage = multer.diskStorage({
 destination: (_req, _file, cb) => cb(null, uploadDir),
 filename: (_req, file, cb) => cb(null, Date.now() + "-" + Math.random().toString(16).slice(2) + path.extname(file.originalname).toLowerCase())
});
const upload = multer({
 storage, limits:{fileSize: 4*1024*1024},
 fileFilter: (_req, file, cb) => cb(null, /^image\\/(jpeg|png|webp|gif)$/.test(file.mimetype))
});

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.urlencoded({extended:true}));
app.use(express.json());
app.use(methodOverride("_method"));
app.use(express.static(path.join(__dirname, "public")));
app.use(session({
 secret: process.env.SESSION_SECRET || "replace-this-session-secret",
 resave:false, saveUninitialized:false,
 store:new SQLiteStore({db:"sessions.sqlite", dir:__dirname}),
 cookie:{httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV==="production", maxAge:7*24*60*60*1000}
}));
app.use((req,res,next)=>{
 res.locals.user = req.session.user || null;
 res.locals.storeName = STORE;
 res.locals.currency = CURRENCY;
 res.locals.cartCount = Object.values(req.session.cart || {}).reduce((a,b)=>a+b,0);
 res.locals.notice = req.session.notice || null;
 delete req.session.notice;
 next();
});
const flash=(req,msg)=>{req.session.notice=msg;};
const requireLogin=(req,res,next)=>req.session.user?next():res.redirect("/login");
const requireAdmin=(req,res,next)=>req.session.user?.role==="admin"?next():res.status(403).render("error",{title:"Access denied",message:"Admin access is required."});
const limiter=rateLimit({windowMs:15*60*1000,limit:100,standardHeaders:true,legacyHeaders:false});
app.use("/login",limiter); app.use("/register",limiter);

app.get("/",(req,res)=>{
 const q=(req.query.q||"").trim();
 const cat=req.query.category?Number(req.query.category):null;
 let sql="SELECT p.*, c.name category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1";
 const args=[];
 if(q){sql+=" AND (p.name LIKE ? OR p.description LIKE ?)";args.push(`%${q}%`,`%${q}%`);}
 if(cat){sql+=" AND p.category_id=?";args.push(cat);}
 sql+=" ORDER BY p.created_at DESC";
 res.render("home",{products:db.prepare(sql).all(...args),categories:db.prepare("SELECT * FROM categories ORDER BY name").all(),q,selectedCategory:cat});
});
app.get("/product/:id",(req,res)=>{
 const product=db.prepare("SELECT p.*,c.name category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=? AND p.active=1").get(req.params.id);
 if(!product)return res.status(404).render("error",{title:"Not found",message:"This product is unavailable."});
 res.render("product",{product});
});
app.get("/register",(req,res)=>res.render("auth",{mode:"register"}));
app.post("/register",async(req,res)=>{
 const {name,email,password}=req.body;
 if(!name?.trim()||!email||!password||password.length<8){flash(req,"Enter your name, a valid email and a password of at least 8 characters.");return res.redirect("/register");}
 try{
  const hash=await bcrypt.hash(password,12);
  const info=db.prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)").run(name.trim(),email.toLowerCase(),hash);
  req.session.user={id:info.lastInsertRowid,name:name.trim(),email:email.toLowerCase(),role:"customer"};
  return res.redirect("/");
 }catch(e){flash(req,"That email address is already registered.");return res.redirect("/register");}
});
app.get("/login",(req,res)=>res.render("auth",{mode:"login"}));
app.post("/login",async(req,res)=>{
 const email=(req.body.email||"").toLowerCase();
 const user=db.prepare("SELECT * FROM users WHERE email=?").get(email);
 if(!user||!(await bcrypt.compare(req.body.password||"",user.password))){flash(req,"Email or password is incorrect.");return res.redirect("/login");}
 req.session.regenerate(err=>{if(err)return res.status(500).send("Could not start session.");req.session.user={id:user.id,name:user.name,email:user.email,role:user.role};res.redirect(user.role==="admin"?"/admin":"/");});
});
app.post("/logout",(req,res)=>req.session.destroy(()=>res.redirect("/")));

app.post("/cart/add/:id",(req,res)=>{
 const p=db.prepare("SELECT id,stock FROM products WHERE id=? AND active=1").get(req.params.id);
 if(!p)return res.redirect("/");
 const qty=Math.max(1,Math.min(20,Number(req.body.quantity)||1));
 req.session.cart=req.session.cart||{};
 const current=req.session.cart[p.id]||0;
 req.session.cart[p.id]=Math.min(p.stock,current+qty);
 flash(req,"Product added to your cart.");res.redirect("/cart");
});
app.get("/cart",(req,res)=>{
 const cart=req.session.cart||{};
 const ids=Object.keys(cart).map(Number);
 const products=ids.length?db.prepare(`SELECT * FROM products WHERE id IN (${ids.map(()=>"?").join(",")})`).all(...ids):[];
 const items=products.map(p=>({...p,quantity:cart[p.id],line_total:p.price*cart[p.id]}));
 res.render("cart",{items,total:items.reduce((s,p)=>s+p.line_total,0)});
});
app.post("/cart/update",(req,res)=>{
 const cart=req.session.cart||{};
 for(const [id,val] of Object.entries(req.body.qty||{})){
  const p=db.prepare("SELECT stock FROM products WHERE id=?").get(id);
  if(!p||Number(val)<=0)delete cart[id];else cart[id]=Math.min(p.stock,Math.max(1,Number(val)||1));
 }
 req.session.cart=cart;res.redirect("/cart");
});
app.post("/cart/remove/:id",(req,res)=>{if(req.session.cart)delete req.session.cart[req.params.id];res.redirect("/cart");});
app.get("/checkout",requireLogin,(req,res)=>{
 const cart=req.session.cart||{};const ids=Object.keys(cart).map(Number);
 const products=ids.length?db.prepare(`SELECT * FROM products WHERE id IN (${ids.map(()=>"?").join(",")})`).all(...ids):[];
 const items=products.map(p=>({...p,quantity:cart[p.id]}));
 if(!items.length){flash(req,"Your cart is empty.");return res.redirect("/cart");}
 res.render("checkout",{items,total:items.reduce((s,p)=>s+p.price*p.quantity,0)});
});
app.post("/checkout",requireLogin,(req,res)=>{
 const {customer_name,phone,address,notes}=req.body;
 const cart=req.session.cart||{};const ids=Object.keys(cart).map(Number);
 if(!customer_name?.trim()||!phone?.trim()||!address?.trim()){flash(req,"Please complete your delivery details.");return res.redirect("/checkout");}
 const products=ids.length?db.prepare(`SELECT * FROM products WHERE id IN (${ids.map(()=>"?").join(",")}) AND active=1`).all(...ids):[];
 if(!products.length){flash(req,"Your cart is empty.");return res.redirect("/cart");}
 const items=products.map(p=>({...p,quantity:cart[p.id]}));
 if(items.some(p=>p.stock<p.quantity)){flash(req,"Some products no longer have enough stock. Please update your cart.");return res.redirect("/cart");}
 const total=items.reduce((s,p)=>s+p.price*p.quantity,0);
 const place=db.transaction(()=>{
  const order=db.prepare("INSERT INTO orders(user_id,total,customer_name,phone,address,notes) VALUES(?,?,?,?,?,?)")
   .run(req.session.user.id,total,customer_name.trim(),phone.trim(),address.trim(),notes||"");
  const add=db.prepare("INSERT INTO order_items(order_id,product_id,product_name,price,quantity) VALUES(?,?,?,?,?)");
  const stock=db.prepare("UPDATE products SET stock=stock-? WHERE id=?");
  items.forEach(p=>{add.run(order.lastInsertRowid,p.id,p.name,p.price,p.quantity);stock.run(p.quantity,p.id);});
  return order.lastInsertRowid;
 });
 const orderId=place();req.session.cart={};res.redirect(`/orders/${orderId}`);
});
app.get("/orders",requireLogin,(req,res)=>res.render("orders",{orders:db.prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC").all(req.session.user.id)}));
app.get("/orders/:id",requireLogin,(req,res)=>{
 const order=db.prepare("SELECT * FROM orders WHERE id=? AND user_id=?").get(req.params.id,req.session.user.id);
 if(!order)return res.status(404).render("error",{title:"Not found",message:"Order not found."});
 const items=db.prepare("SELECT * FROM order_items WHERE order_id=?").all(order.id);
 res.render("order",{order,items});
});

app.get("/admin",requireAdmin,(req,res)=>{
 const stats={
  orders:db.prepare("SELECT COUNT(*) n FROM orders").get().n,
  pending:db.prepare("SELECT COUNT(*) n FROM orders WHERE status='Pending'").get().n,
  products:db.prepare("SELECT COUNT(*) n FROM products").get().n,
  customers:db.prepare("SELECT COUNT(*) n FROM users WHERE role='customer'").get().n,
  revenue:db.prepare("SELECT COALESCE(SUM(total),0) n FROM orders WHERE status!='Cancelled'").get().n
 };
 res.render("admin/dashboard",{stats,orders:db.prepare("SELECT o.*,u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 8").all()});
});
app.get("/admin/products",requireAdmin,(req,res)=>res.render("admin/products",{products:db.prepare("SELECT p.*,c.name category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC").all()}));
app.get("/admin/products/new",requireAdmin,(req,res)=>res.render("admin/product-form",{product:null,categories:db.prepare("SELECT * FROM categories ORDER BY name").all()}));
app.post("/admin/products",requireAdmin,upload.single("image"),(req,res)=>{
 const {name,description,price,compare_price,stock,category_id}=req.body;
 if(!name||Number(price)<0||!Number.isFinite(Number(price))){flash(req,"Please enter a product name and valid price.");return res.redirect("/admin/products/new");}
 const image=req.file?"/uploads/"+req.file.filename:"";
 db.prepare("INSERT INTO products(name,description,price,compare_price,stock,category_id,image) VALUES(?,?,?,?,?,?,?)")
 .run(name,description||"",Number(price),Number(compare_price)||0,Math.max(0,Number(stock)||0),Number(category_id)||null,image);
 flash(req,"Product created.");res.redirect("/admin/products");
});
app.get("/admin/products/:id/edit",requireAdmin,(req,res)=>{
 const product=db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id);
 if(!product)return res.redirect("/admin/products");
 res.render("admin/product-form",{product,categories:db.prepare("SELECT * FROM categories ORDER BY name").all()});
});
app.put("/admin/products/:id",requireAdmin,upload.single("image"),(req,res)=>{
 const old=db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id);if(!old)return res.redirect("/admin/products");
 const b=req.body;const image=req.file?"/uploads/"+req.file.filename:old.image;
 db.prepare("UPDATE products SET name=?,description=?,price=?,compare_price=?,stock=?,category_id=?,image=?,active=? WHERE id=?")
 .run(b.name,b.description||"",Number(b.price),Number(b.compare_price)||0,Math.max(0,Number(b.stock)||0),Number(b.category_id)||null,image,b.active==="1"?1:0,req.params.id);
 flash(req,"Product updated.");res.redirect("/admin/products");
});
app.delete("/admin/products/:id",requireAdmin,(req,res)=>{db.prepare("UPDATE products SET active=0 WHERE id=?").run(req.params.id);flash(req,"Product hidden from the store.");res.redirect("/admin/products");});
app.get("/admin/categories",requireAdmin,(req,res)=>res.render("admin/categories",{categories:db.prepare("SELECT c.*,COUNT(p.id) product_count FROM categories c LEFT JOIN products p ON p.category_id=c.id GROUP BY c.id ORDER BY c.name").all()}));
app.post("/admin/categories",requireAdmin,(req,res)=>{
 const name=(req.body.name||"").trim();if(!name){flash(req,"Category name is required.");return res.redirect("/admin/categories");}
 try{db.prepare("INSERT INTO categories(name,description) VALUES(?,?)").run(name,req.body.description||"");flash(req,"Category added.");}catch(e){flash(req,"That category already exists.");}
 res.redirect("/admin/categories");
});
app.delete("/admin/categories/:id",requireAdmin,(req,res)=>{
 db.prepare("UPDATE products SET category_id=NULL WHERE category_id=?").run(req.params.id);
 db.prepare("DELETE FROM categories WHERE id=?").run(req.params.id);flash(req,"Category deleted.");res.redirect("/admin/categories");
});
app.get("/admin/orders",requireAdmin,(req,res)=>res.render("admin/orders",{orders:db.prepare("SELECT o.*,u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC").all()}));
app.get("/admin/orders/:id",requireAdmin,(req,res)=>{
 const order=db.prepare("SELECT o.*,u.email FROM orders o JOIN users u ON u.id=o.user_id WHERE o.id=?").get(req.params.id);
 if(!order)return res.redirect("/admin/orders");
 res.render("admin/order",{order,items:db.prepare("SELECT * FROM order_items WHERE order_id=?").all(order.id)});
});
app.post("/admin/orders/:id/status",requireAdmin,(req,res)=>{
 const allowed=["Pending","Confirmed","Processing","Shipped","Delivered","Cancelled"];
 if(allowed.includes(req.body.status))db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);
 flash(req,"Order status updated.");res.redirect(`/admin/orders/${req.params.id}`);
});
app.post("/admin/orders/:id/payment",requireAdmin,(req,res)=>{
 if(["Pending","Paid","Failed","Refunded"].includes(req.body.payment_status))db.prepare("UPDATE orders SET payment_status=? WHERE id=?").run(req.body.payment_status,req.params.id);
 res.redirect(`/admin/orders/${req.params.id}`);
});
app.get("/admin/customers",requireAdmin,(req,res)=>res.render("admin/customers",{customers:db.prepare("SELECT id,name,email,created_at FROM users WHERE role='customer' ORDER BY id DESC").all()}));
app.get("/health",(req,res)=>res.json({ok:true,store:STORE}));
app.use((req,res)=>res.status(404).render("error",{title:"Page not found",message:"The page you are looking for does not exist."}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).render("error",{title:"Something went wrong",message:"Please try again. Check the server logs if the issue continues."});});
app.listen(PORT,"0.0.0.0",()=>console.log(`${STORE} running on port ${PORT}`));
