# Shopora — Shopping Website

A full-stack Node.js/Express + SQLite store with customer registration/login, product catalog, categories, cart, checkout, customer order history, and an admin dashboard.

## Features
- Customer registration, login and logout (hashed passwords, session cookies)
- Product listing, search, category filtering and product detail pages
- Shopping cart with quantity updates and stock checks
- Checkout with Cash on Delivery
- Order confirmation page and customer order history
- Admin dashboard with order/revenue/customer/product summaries
- Admin product create/edit/hide, prices, compare-at prices, stock and image upload
- Admin category create/delete
- Admin order list, customer details, status updates and payment-status tracking
- SQLite database; persistent order and session data
- Responsive layout for mobile and desktop

## Requirements
Node.js 20 or newer and npm.

## Run locally / on your VPS
```bash
unzip shopora-store.zip
cd shopora-store
cp .env.example .env
nano .env
npm install
npm start
```
Open `http://YOUR_SERVER_IP:3000`.

Set a strong `SESSION_SECRET`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` in `.env` before first start. The initial admin account is created from those values when the database is first created. If the database already exists, changing `.env` does not reset the admin password.

## Run 24/7 with PM2
```bash
sudo npm install -g pm2
pm2 start server.js --name shopora
pm2 save
pm2 startup
```
Run the command printed by `pm2 startup`, then:
```bash
pm2 status
pm2 logs shopora
```

## Nginx / Cloudflare
Proxy your domain to `http://127.0.0.1:3000` using Nginx, then point your Cloudflare Tunnel hostname to the Nginx listener or directly to `http://localhost:3000`. Do not expose the admin credentials publicly. Use HTTPS for the public site.

## Important production notes
- This is a working starter store, not a fully audited commerce platform.
- Checkout currently supports Cash on Delivery. Online payments (Razorpay/Stripe) need merchant credentials and a verified payment callback/webhook before marking orders paid.
- Configure backups for `data.sqlite`, `sessions.sqlite`, and `public/uploads/`.
- Add CSRF protection, email/SMS notifications, shipping/tax rules, privacy/terms pages and a proper transactional email provider before taking real customer orders.
- Uploads are limited to common image MIME types and 4 MB.
